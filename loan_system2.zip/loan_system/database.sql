-- =========================================================
-- LOAN / RENT / MOI MANAGEMENT SYSTEM - DATABASE STRUCTURE
-- =========================================================
CREATE DATABASE IF NOT EXISTS loan_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE loan_management;

-- ---------------------------------------------------------
-- 1. INTEREST MODULE
-- ---------------------------------------------------------
CREATE TABLE interest_customers (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    name                    VARCHAR(150) NOT NULL,
    village                 VARCHAR(150) NOT NULL,
    mobile                  VARCHAR(15)  NOT NULL UNIQUE,
    principal               DECIMAL(12,2) NOT NULL,
    principal_balance       DECIMAL(12,2) NOT NULL,
    rate_of_interest        DECIMAL(5,2)  NOT NULL,
    transaction_date        DATE NOT NULL,
    payment_type            ENUM('100days','10weeks','monthly') NOT NULL,
    no_of_payments          INT DEFAULT 0,
    total_interest_collected DECIMAL(12,2) DEFAULT 0,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE interest_collections (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    collection_date DATE NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    status          ENUM('partial','complete') NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES interest_customers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE interest_principal_collections (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    collection_date DATE NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    status          ENUM('partial','complete') NOT NULL DEFAULT 'partial',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES interest_customers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 2. BORROWER MODULE
-- ---------------------------------------------------------
CREATE TABLE borrower_customers (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    village         VARCHAR(150) NOT NULL,
    mobile          VARCHAR(15)  NOT NULL UNIQUE,
    principal       DECIMAL(12,2) NOT NULL,
    balance         DECIMAL(12,2) NOT NULL,
    transaction_date DATE NOT NULL,
    payment_type    ENUM('100days','10weeks','monthly') NOT NULL,
    due_count       INT DEFAULT 0,
    day_count       INT DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE borrower_collections (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    collection_date DATE NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    status          ENUM('partial','complete') NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES borrower_customers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 3. RENT MODULE
-- ---------------------------------------------------------
CREATE TABLE rent_customers (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    village         VARCHAR(150) NOT NULL,
    mobile          VARCHAR(15)  NOT NULL UNIQUE,
    rent_amount     DECIMAL(12,2) NOT NULL,
    agreement_date  DATE NOT NULL,
    status          ENUM('paid','pending') DEFAULT 'pending',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE rent_payments (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    payment_date    DATE NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES rent_customers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 4. MOI (DETAILS) MODULE
-- ---------------------------------------------------------
CREATE TABLE moi_records (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    name_tamil       VARCHAR(150),
    name_english     VARCHAR(150),
    village_tamil    VARCHAR(150),
    village_english  VARCHAR(150),
    mobile           VARCHAR(15) UNIQUE,
    alternate_mobile VARCHAR(15),
    city             VARCHAR(100),
    income           DECIMAL(12,2),
    expenditure      DECIMAL(12,2),
    information      TEXT,
    up_dated         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Sample seed row for MOI (optional, remove if not needed)
-- INSERT INTO moi_records (name_tamil,name_english,village_tamil,village_english,mobile,alternate_mobile,city,income,expenditure,information)
-- VALUES ('குமார்','Kumar','செம்மலை','Semmalai','9876543210','9876500000','Theni',25000,18000,'Sample record');

-- =========================================================
-- MIGRATION (run these instead of the CREATE TABLE statements
-- above if you already have an existing database and don't
-- want to drop your data):
-- ALTER TABLE interest_principal_collections ADD COLUMN status ENUM('partial','complete') NOT NULL DEFAULT 'partial' AFTER amount;
-- ALTER TABLE moi_records ADD COLUMN alternate_mobile VARCHAR(15) AFTER mobile;
-- =========================================================
