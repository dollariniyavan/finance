<?php
// ==========================================================
// DATABASE BACKUP — generates a full SQL dump (structure +
// data) for every table in the configured database, using
// pure PHP/mysqli so it works even when shell_exec/mysqldump
// is disabled on the host.
// ==========================================================
require_once 'config.php';
$db = getDB();

$filename = 'backup_' . DB_NAME . '_' . date('Ymd_His') . '.sql';
header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

echo "-- Database backup for `" . DB_NAME . "`\n";
echo "-- Generated: " . date('Y-m-d H:i:s') . "\n";
echo "-- ==========================================================\n\n";
echo "SET FOREIGN_KEY_CHECKS=0;\n\n";

$tablesResult = $db->query("SHOW TABLES");
$tables = [];
while ($row = $tablesResult->fetch_array()) $tables[] = $row[0];

foreach ($tables as $table) {
    // ---- Structure ----
    echo "-- --------------------------------------------------------\n";
    echo "-- Table structure for `$table`\n";
    echo "-- --------------------------------------------------------\n";
    echo "DROP TABLE IF EXISTS `$table`;\n";
    $createRow = $db->query("SHOW CREATE TABLE `$table`")->fetch_assoc();
    echo $createRow['Create Table'] . ";\n\n";

    // ---- Data ----
    $dataResult = $db->query("SELECT * FROM `$table`");
    if ($dataResult->num_rows > 0) {
        echo "-- Data for `$table`\n";
        $fields = $dataResult->fetch_fields();
        $fieldNames = array_map(fn($f) => $f->name, $fields);
        $columnList = '`' . implode('`,`', $fieldNames) . '`';

        while ($row = $dataResult->fetch_assoc()) {
            $values = array_map(function ($v) use ($db) {
                if ($v === null) return 'NULL';
                return "'" . $db->real_escape_string($v) . "'";
            }, $row);
            echo "INSERT INTO `$table` ($columnList) VALUES (" . implode(',', $values) . ");\n";
        }
        echo "\n";
    }
}

echo "SET FOREIGN_KEY_CHECKS=1;\n";
