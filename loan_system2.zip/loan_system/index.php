<!DOCTYPE html>
<html lang="ta">
<head>
<meta charset="UTF-8">
<title>Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/style.css">
<style>
.page { display: none; }
.page.active { display: block; }
.global-nav {
    display: flex;
    gap: 6px;
    background: #14283f;
    padding: 10px 16px;
    flex-wrap: wrap;
    align-items: center;
    position: sticky;
    top: 0;
    z-index: 500;
}
.global-nav .nav-item {
    display: flex;
    align-items: center;
    gap: 6px;
    background: transparent;
    border: none;
    color: #cfd6dd;
    padding: 8px 14px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
}
.global-nav .nav-item .nav-icon { font-size: 18px; }
.global-nav .nav-item:hover { background: rgba(255,255,255,.08); color: #fff; }
.global-nav .nav-item.active { background: #ffb703; color: #1e3a5f; }
.global-nav .nav-spacer { flex: 1; }
</style>
</head>
<body>

<nav class="global-nav">
    <button class="nav-item" data-page="interest" onclick="showPage('interest')">
        <span class="nav-icon">💰</span> Interest
    </button>
    <button class="nav-item" data-page="borrower" onclick="showPage('borrower')">
        <span class="nav-icon">🤝</span> Borrower
    </button>
    <button class="nav-item" data-page="rent" onclick="showPage('rent')">
        <span class="nav-icon">🏠</span> House Rent
    </button>
    <button class="nav-item" data-page="moi" onclick="showPage('moi')">
        <span class="nav-icon">📇</span> MOI / Details
    </button>
    <span class="nav-spacer"></span>
    <button class="nav-item" onclick="openModal('dbModal')">
        <span class="nav-icon">🗄</span> Backup / Restore
    </button>
</nav>

<section id="page-interest" class="page active">
<div class="topbar">
    <h1>💰 Interest</h1>
</div>
<div class="container">

    <div class="toolbar">
        <input type="text" id="int_searchBox" placeholder="Search id, name, village, mobile, principal, rate, date...">
        <button class="mic-btn" id="int_micBtn" title="Voice search (Tamil)">🎤</button>
        <select id="int_villageFilter"><option value="">All Villages</option></select>
        <button class="btn btn-add" onclick="openModal('int_addModal')">+ New Interest Record</button>
    </div>

    <div style="overflow-x:auto;">
    <table>
        <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Village</th><th>Mobile</th><th>Principal</th>
            <th>Principal Balance</th><th>Rate %</th><th>Date</th><th>No. of Payments</th>
            <th>Total Interest Collected</th><th>Actions</th>
        </tr>
        </thead>
        <tbody id="int_tableBody">
        <tr><td colspan="11">Loading...</td></tr>
        </tbody>
    </table>
    </div>
</div>

<!-- ===================== ADD NEW RECORD MODAL ===================== -->
<div class="modal-overlay" id="int_addModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('int_addModal')">&times;</button>
        <h2>New Interest Record</h2>
        <form id="int_addForm">
            <div class="form-grid">
                <div><label>Name</label><input type="text" name="name" required></div>
                <div><label>Village</label><input type="text" name="village" required></div>
                <div><label>Mobile</label><input type="text" name="mobile" required></div>
                <div><label>Principal</label><input type="number" step="0.01" name="principal" required></div>
                <div><label>Rate of Interest (%)</label><input type="number" step="0.01" name="rate_of_interest" required></div>
                <div><label>Transaction Date</label><input type="date" name="transaction_date" value="<?= date('Y-m-d') ?>" required></div>
            </div>
            <div class="modal-btn-row">
                <button type="button" class="btn btn-save" onclick="int_submitAdd(false)">Save</button>
                <button type="button" class="btn btn-save" onclick="int_submitAdd(true)">Submit &amp; Print</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal('int_addModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- ===================== VIEW MODAL (3 tabs) ===================== -->
<div class="modal-overlay" id="int_viewModal">
    <div class="modal-box" style="max-width:760px;">
        <button class="modal-close" onclick="closeModal('int_viewModal')">&times;</button>
        <h2>Customer Details</h2>
        <div class="tab-buttons">
            <button class="active" onclick="int_showTab('int_tabDetails', this)">Customer Details</button>
            <button onclick="int_showTab('int_tabInterest', this)">Interest Collection</button>
            <button onclick="int_showTab('int_tabPrincipal', this)">Principal Collection</button>
        </div>

        <div class="tab-content active" id="int_tabDetails">
            <div class="readonly-box" id="int_viewCustomerBox"></div>
            <div class="modal-btn-row">
                <button class="btn btn-print" onclick="printSection('int_viewCustomerBox','Customer Details')">🖨 Print Customer Details</button>
                <button class="btn btn-pay" onclick="int_openCollectModal('interest')">Interest Collection</button>
                <button class="btn btn-pay" onclick="int_openCollectModal('principal')">Principal Collection</button>
            </div>
        </div>

        <div class="tab-content" id="int_tabInterest">
            <div id="int_interestHistoryBox"></div>
            <div class="modal-btn-row">
                <button class="btn btn-print" onclick="printSection('int_interestHistoryBox','Interest Collection History')">🖨 Print</button>
            </div>
        </div>

        <div class="tab-content" id="int_tabPrincipal">
            <div id="int_principalHistoryBox"></div>
            <div class="modal-btn-row">
                <button class="btn btn-print" onclick="printSection('int_principalHistoryBox','Principal Collection History')">🖨 Print</button>
            </div>
        </div>
    </div>
</div>

<!-- ===================== COLLECT (Interest / Principal / Pay) MODAL ===================== -->
<div class="modal-overlay" id="int_collectModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('int_collectModal')">&times;</button>
        <h2 id="int_collectTitle">Interest Collection</h2>
        <div class="readonly-box" id="int_collectCustomerBox"></div>
        <form id="int_collectForm">
            <input type="hidden" id="int_collectMode" value="interest">
            <input type="hidden" id="int_collectCustomerId">
            <div class="form-grid">
                <div><label>Amount</label><input type="number" step="0.01" id="int_collectAmount" required></div>
                <div><label>Date</label><input type="date" id="int_collectDate" required></div>
            </div>
            <p style="font-size:12px;color:#777;margin-top:6px;">Payment status is set automatically: "Complete" once the remaining principal balance reaches 0, otherwise "Partial".</p>
            <div class="modal-btn-row">
                <button type="button" class="btn btn-save" onclick="int_submitCollect(false)">Save</button>
                <button type="button" class="btn btn-save" onclick="int_submitCollect(true)">Submit &amp; Print</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal('int_collectModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>
</section>

<section id="page-borrower" class="page">
<div class="topbar">
    <h1>🤝 Borrower</h1>
</div>
<div class="container">

    <div class="toolbar">
        <input type="text" id="bor_searchBox" placeholder="Search id, name, village, mobile, principal, balance...">
        <button class="mic-btn" id="bor_micBtn" title="Voice search (Tamil)">🎤</button>
        <select id="bor_villageFilter"><option value="">All Villages</option></select>
        <button class="btn btn-add" onclick="openModal('bor_addModal')">+ New Borrower Record</button>
    </div>

    <div style="overflow-x:auto;">
    <table>
        <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Village</th><th>Mobile</th><th>Principal</th>
            <th>Balance</th><th>Due Count</th><th>Day Count</th><th>Actions</th>
        </tr>
        </thead>
        <tbody id="bor_tableBody"><tr><td colspan="9">Loading...</td></tr></tbody>
    </table>
    </div>
</div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="bor_addModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('bor_addModal')">&times;</button>
        <h2>New Borrower Record</h2>
        <form id="bor_addForm">
            <div class="form-grid">
                <div><label>Name</label><input type="text" name="name" required></div>
                <div><label>Village</label><input type="text" name="village" required></div>
                <div><label>Mobile</label><input type="text" name="mobile" required></div>
                <div><label>Principal</label><input type="number" step="0.01" name="principal" required></div>
                <div><label>Date</label><input type="date" name="transaction_date" value="<?= date('Y-m-d') ?>" required></div>
                <div class="full">
                    <label>Payment Schedule</label>
                    <select name="payment_type">
                        <option value="100days">100 Days</option>
                        <option value="10weeks">10 Weeks</option>
                        <option value="monthly">Monthly (up to 5 months)</option>
                    </select>
                </div>
            </div>
            <div class="modal-btn-row">
                <button type="button" class="btn btn-save" onclick="bor_submitAdd(false)">Add</button>
                <button type="button" class="btn btn-save" onclick="bor_submitAdd(true)">Submit &amp; Print</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal('bor_addModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- VIEW MODAL (2 parts) -->
<div class="modal-overlay" id="bor_viewModal">
    <div class="modal-box" style="max-width:700px;">
        <button class="modal-close" onclick="closeModal('bor_viewModal')">&times;</button>
        <h2>Borrower Details</h2>
        <div class="tab-buttons">
            <button class="active" onclick="bor_showTab('bor_tabDetails', this)">Customer Details</button>
            <button onclick="bor_showTab('bor_tabHistory', this)">Transaction History</button>
        </div>
        <div class="tab-content active" id="bor_tabDetails">
            <div class="readonly-box" id="bor_viewCustomerBox"></div>
            <div class="modal-btn-row">
                <button class="btn btn-print" onclick="printSection('bor_viewCustomerBox','Customer Details')">🖨 Print Customer Details</button>
            </div>
        </div>
        <div class="tab-content" id="bor_tabHistory">
            <div id="bor_historyBox"></div>
            <div class="modal-btn-row">
                <button class="btn btn-print" onclick="printSection('bor_historyBox','Transaction History')">🖨 Print</button>
            </div>
        </div>
    </div>
</div>

<!-- PAY DUE MODAL -->
<div class="modal-overlay" id="bor_payModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('bor_payModal')">&times;</button>
        <h2>Pay Due</h2>
        <div class="readonly-box" id="bor_payCustomerBox"></div>
        <form id="bor_payForm">
            <input type="hidden" id="bor_payCustomerId">
            <div class="form-grid">
                <div><label>Due Amount</label><input type="number" step="0.01" id="bor_payAmount" required></div>
                <div><label>Date</label><input type="date" id="bor_payDate" required></div>
            </div>
            <div class="modal-btn-row">
                <button type="button" class="btn btn-save" onclick="bor_submitPay(false)">Save</button>
                <button type="button" class="btn btn-save" onclick="bor_submitPay(true)">Submit &amp; Print</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal('bor_payModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>
</section>

<section id="page-rent" class="page">
<div class="topbar">
    <h1>🏠 House Rent</h1>
</div>
<div class="container">

    <div class="toolbar">
        <input type="text" id="rnt_searchBox" placeholder="Search id, name, village, mobile, rent, date, status...">
        <button class="mic-btn" id="rnt_micBtn" title="Voice search (Tamil)">🎤</button>
        <select id="rnt_villageFilter"><option value="">All Villages</option></select>
        <button class="btn btn-add" onclick="openModal('rnt_addModal')">+ New Rent Record</button>
    </div>

    <div style="overflow-x:auto;">
    <table>
        <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Village</th><th>Mobile</th><th>Rent Amount</th>
            <th>Agreement Date</th><th>Status</th><th>Actions</th>
        </tr>
        </thead>
        <tbody id="rnt_tableBody"><tr><td colspan="8">Loading...</td></tr></tbody>
    </table>
    </div>
</div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="rnt_addModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('rnt_addModal')">&times;</button>
        <h2>New Rent Record</h2>
        <form id="rnt_addForm">
            <div class="form-grid">
                <div><label>Name</label><input type="text" name="name" required></div>
                <div><label>Village</label><input type="text" name="village" required></div>
                <div><label>Mobile</label><input type="text" name="mobile" required></div>
                <div><label>Rent Amount</label><input type="number" step="0.01" name="rent_amount" required></div>
                <div class="full"><label>Agreement Date</label><input type="date" name="agreement_date" required></div>
            </div>
            <div class="modal-btn-row">
                <button type="button" class="btn btn-save" onclick="rnt_submitAdd(false)">Save</button>
                <button type="button" class="btn btn-save" onclick="rnt_submitAdd(true)">Submit &amp; Print</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal('rnt_addModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- VIEW MODAL -->
<div class="modal-overlay" id="rnt_viewModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('rnt_viewModal')">&times;</button>
        <h2>Rent Details</h2>
        <div class="readonly-box" id="rnt_viewCustomerBox"></div>
        <h3>Payment History</h3>
        <div id="rnt_historyBox"></div>
        <div class="modal-btn-row">
            <button class="btn btn-print" onclick="printSection('rnt_viewCustomerBox','Rent Details')">🖨 Print</button>
        </div>
    </div>
</div>

<!-- PAY MODAL -->
<div class="modal-overlay" id="rnt_payModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('rnt_payModal')">&times;</button>
        <h2>Rent Payment</h2>
        <div class="readonly-box" id="rnt_payCustomerBox"></div>
        <form id="rnt_payForm">
            <input type="hidden" id="rnt_payCustomerId">
            <div class="form-grid">
                <div><label>Amount</label><input type="number" step="0.01" id="rnt_payAmount" required></div>
                <div><label>Date</label><input type="date" id="rnt_payDate" required></div>
            </div>
            <div class="modal-btn-row">
                <button type="button" class="btn btn-save" onclick="rnt_submitPay(false)">Save</button>
                <button type="button" class="btn btn-save" onclick="rnt_submitPay(true)">Submit &amp; Print</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal('rnt_payModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>
</section>

<section id="page-moi" class="page">
<div class="topbar">
    <h1>📇 MOI / Details</h1>
</div>
<div class="container">

    <div class="toolbar">
        <input type="text" id="moi_searchBox" placeholder="Search all columns (Tamil name, English name, village, mobile...)">
        <button class="mic-btn" id="moi_micBtn" title="Voice search (Tamil)">🎤</button>
        <select id="moi_villageFilter"><option value="">All Villages (English)</option></select>
        <button class="btn btn-add" onclick="openModal('moi_addModal')">+ New Record</button>
        <button class="btn btn-print" onclick="moi_printPDF()">🖨 Print PDF (Name/Village-Tamil, Income, Expenditure)</button>
    </div>

    <div style="overflow-x:auto;">
    <table id="moi_moiTable">
        <thead>
        <tr>
            <th class="sortable" data-col="0">ID</th>
            <th class="sortable" data-col="1">Name (Tamil)</th>
            <th class="sortable" data-col="2">Name (English)</th>
            <th class="sortable" data-col="3">Village (Tamil)</th>
            <th class="sortable" data-col="4">Village (English)</th>
            <th class="sortable" data-col="5">Mobile</th>
            <th class="sortable" data-col="6">Alternate Mobile</th>
            <th class="sortable" data-col="7">City</th>
            <th class="sortable" data-col="8">Income</th>
            <th class="sortable" data-col="9">Expenditure</th>
            <th class="sortable" data-col="10">Information</th>
            <th class="sortable" data-col="11">Updated</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody id="moi_tableBody"><tr><td colspan="13">Loading...</td></tr></tbody>
    </table>
    </div>
</div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="moi_addModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('moi_addModal')">&times;</button>
        <h2>New MOI Record</h2>
        <form id="moi_addForm">
            <div class="form-grid">
                <div><label>Name (Tamil)</label><input type="text" name="name_tamil"></div>
                <div><label>Name (English)</label><input type="text" name="name_english"></div>
                <div><label>Village (Tamil)</label><input type="text" name="village_tamil"></div>
                <div><label>Village (English)</label><input type="text" name="village_english"></div>
                <div><label>Mobile</label><input type="text" name="mobile"></div>
                <div><label>Alternate Mobile</label><input type="text" name="alternate_mobile"></div>
                <div><label>City</label><input type="text" name="city"></div>
                <div><label>Income</label><input type="number" step="0.01" name="income"></div>
                <div><label>Expenditure</label><input type="number" step="0.01" name="expenditure"></div>
                <div class="full"><label>Information</label><input type="text" name="information"></div>
            </div>
            <div class="modal-btn-row">
                <button type="button" class="btn btn-save" onclick="moi_submitAdd()">Save</button>
                <button type="button" class="btn btn-cancel" onclick="closeModal('moi_addModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>
</section>

<!-- ===================== DATABASE BACKUP / RESTORE MODAL (available on every page) ===================== -->
<div class="modal-overlay" id="dbModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('dbModal')">&times;</button>
        <h2>🗄 Database Backup / Restore</h2>

        <div style="margin-bottom:22px;">
            <h3 style="margin-bottom:6px;">Backup</h3>
            <p style="font-size:13px;color:#666;margin-top:0;">Downloads a complete .sql dump (structure + data) of the database.</p>
            <button class="btn btn-save" onclick="dbBackup()">⬇ Download Backup</button>
        </div>

        <div>
            <h3 style="margin-bottom:6px;">Restore</h3>
            <p style="font-size:13px;color:#666;margin-top:0;">
                Upload a .sql backup file to restore. <strong>This replaces existing data in matching tables</strong> —
                only restore a file you trust.
            </p>
            <input type="file" id="dbRestoreFile" accept=".sql">
            <div class="modal-btn-row">
                <button type="button" class="btn btn-pay" onclick="dbRestore()">⬆ Restore from File</button>
            </div>
            <p id="dbRestoreStatus" style="font-size:13px;margin-top:10px;"></p>
        </div>
    </div>
</div>

<script src="assets/common.js"></script>
<script>
// ================= DATABASE BACKUP / RESTORE =================
function dbBackup() {
    window.location.href = 'backup.php';
}
function dbRestore() {
    const fileInput = document.getElementById('dbRestoreFile');
    const statusEl = document.getElementById('dbRestoreStatus');
    if (!fileInput.files.length) {
        statusEl.textContent = 'Please choose a .sql file first.';
        statusEl.style.color = '#e63946';
        return;
    }
    if (!confirm('This will overwrite existing data in matching tables. Continue?')) return;

    statusEl.textContent = 'Restoring... please wait.';
    statusEl.style.color = '#666';
    const fd = new FormData();
    fd.append('sql_file', fileInput.files[0]);
    fetch('restore.php', { method: 'POST', body: fd })
        .then(res => res.json())
        .then(res => {
            statusEl.textContent = res.message;
            statusEl.style.color = res.success ? '#2a9d8f' : '#e63946';
            if (res.success) fileInput.value = '';
        })
        .catch(() => {
            statusEl.textContent = 'Restore failed: could not reach the server.';
            statusEl.style.color = '#e63946';
        });
}

// ================= PAGE NAVIGATION =================
function showPage(name) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById('page-' + name).classList.add('active');
    document.querySelectorAll('.global-nav .nav-item').forEach(b => b.classList.remove('active'));
    const navBtn = document.querySelector(`.global-nav .nav-item[data-page="${name}"]`);
    if (navBtn) navBtn.classList.add('active');
    window.scrollTo(0, 0);
}
// Interest is the default landing page (no separate dashboard)
showPage('interest');

// ================= INTEREST MODULE =================
let int_currentCustomer = null;

function int_loadVillages() {
    apiGet('interest_api.php?action=villages').then(d => {
        const sel = document.getElementById('int_villageFilter');
        sel.innerHTML = '<option value="">All Villages</option>';
        d.villages.forEach(v => {
            const o = document.createElement('option');
            o.value = v; o.textContent = v;
            sel.appendChild(o);
        });
    });
}

function int_loadTable() {
    const q = document.getElementById('int_searchBox').value;
    const village = document.getElementById('int_villageFilter').value;
    apiGet(`interest_api.php?action=list&q=${encodeURIComponent(q)}&village=${encodeURIComponent(village)}`)
    .then(d => {
        const body = document.getElementById('int_tableBody');
        body.innerHTML = '';
        if (!d.rows.length) { body.innerHTML = '<tr><td colspan="11">No records found.</td></tr>'; return; }
        d.rows.forEach(r => {
            const payDisabled = parseFloat(r.principal_balance) <= 0 ? 'disabled' : '';
            body.innerHTML += `<tr>
                <td>${r.id}</td><td>${r.name}</td><td>${r.village}</td><td>${r.mobile}</td>
                <td>${r.principal}</td><td>${r.principal_balance}</td><td>${r.rate_of_interest}</td>
                <td>${r.transaction_date}</td><td>${r.no_of_payments}</td><td>${r.total_interest_collected}</td>
                <td class="actions">
                    <button class="btn btn-view" onclick="int_viewCustomer(${r.id})">View</button>
                    <button class="btn btn-pay" ${payDisabled} onclick="int_quickPay(${r.id}, ${r.principal_balance}, ${r.rate_of_interest})">Pay</button>
                    <button class="btn btn-print" onclick="int_printRow(${r.id})">Print</button>
                </td>
            </tr>`;
        });
    });
}

document.getElementById('int_searchBox').addEventListener('input', debounce(int_loadTable, 350));
document.getElementById('int_villageFilter').addEventListener('change', int_loadTable);
setupVoiceSearch('int_micBtn', 'int_searchBox');

// ---------------- ADD ----------------
function int_submitAdd(andPrint) {
    const f = document.getElementById('int_addForm');
    const data = Object.fromEntries(new FormData(f).entries());
    apiPost('interest_api.php?action=add', data).then(res => {
        if (res.success) {
            closeModal('int_addModal');
            f.reset();
            int_loadTable();
            int_loadVillages();
            if (andPrint) printSectionHtml(`<h3>New Interest Record</h3>
                <p>Name: ${data.name}<br>Village: ${data.village}<br>Mobile: ${data.mobile}<br>
                Principal: ${data.principal}<br>Rate: ${data.rate_of_interest}%<br>Date: ${data.transaction_date}</p>`);
        } else alert(res.message || 'Failed to save.');
    });
}

// ---------------- VIEW ----------------
function int_viewCustomer(id) {
    apiGet('interest_api.php?action=view&id=' + id).then(d => {
        if (!d.success) { alert('Not found'); return; }
        int_currentCustomer = d.customer;
        document.getElementById('int_viewCustomerBox').innerHTML = `
            <b>Name:</b> ${d.customer.name} &nbsp; <b>Village:</b> ${d.customer.village} &nbsp; <b>Mobile:</b> ${d.customer.mobile}<br>
            <b>Rate of Interest:</b> ${d.customer.rate_of_interest}% &nbsp; <b>Principal:</b> ${d.customer.principal}<br>
            <b>Remaining Principal:</b> ${d.customer.principal_balance} &nbsp; <b>Total Interest Collected:</b> ${d.customer.total_interest_collected}`;

        let ih = '<table><tr><th>Date</th><th>Amount</th><th>Status</th></tr>';
        d.interest_history.forEach(r => ih += `<tr><td>${r.collection_date}</td><td>${r.amount}</td>
            <td><span class="badge ${r.status}">${r.status}</span></td></tr>`);
        ih += '</table>';
        document.getElementById('int_interestHistoryBox').innerHTML = ih || 'No records';

        let ph = '<table><tr><th>Date</th><th>Amount</th><th>Status</th></tr>';
        d.principal_history.forEach(r => ph += `<tr><td>${r.collection_date}</td><td>${r.amount}</td>
            <td><span class="badge ${r.status}">${r.status}</span></td></tr>`);
        ph += '</table>';
        document.getElementById('int_principalHistoryBox').innerHTML = ph || 'No records';

        int_showTab('int_tabDetails', document.querySelector('#int_viewModal .tab-buttons button'));
        openModal('int_viewModal');
    });
}

function int_showTab(tabId, btn) {
    document.querySelectorAll('#int_viewModal .tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('#int_viewModal .tab-buttons button').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    btn.classList.add('active');
}

// ---------------- COLLECT (from inside View) ----------------
function int_openCollectModal(mode) {
    document.getElementById('int_collectMode').value = mode;
    document.getElementById('int_collectCustomerId').value = int_currentCustomer.id;
    document.getElementById('int_collectTitle').textContent = mode === 'interest' ? 'Interest Collection' : 'Principal Collection';
    document.getElementById('int_collectCustomerBox').innerHTML = `
        <b>Name:</b> ${int_currentCustomer.name} &nbsp; <b>Village:</b> ${int_currentCustomer.village} &nbsp; <b>Mobile:</b> ${int_currentCustomer.mobile}<br>
        <b>Principal:</b> ${int_currentCustomer.principal} &nbsp; <b>Rate of Interest:</b> ${int_currentCustomer.rate_of_interest}%
        &nbsp; <b>Total Paid Interest:</b> ${int_currentCustomer.total_interest_collected}`;
    // Interest amount is auto-calculated as principal x rate%; principal collection stays manual.
    document.getElementById('int_collectAmount').value = mode === 'interest'
        ? (parseFloat(int_currentCustomer.principal) * parseFloat(int_currentCustomer.rate_of_interest) / 100).toFixed(2)
        : '';
    document.getElementById('int_collectDate').value = new Date().toISOString().slice(0,10);
    openModal('int_collectModal');
}

// ---------------- QUICK PAY (row-level, auto-calculates interest = principal x rate%) ----------------
function int_quickPay(id, balance, rate) {
    int_currentCustomer = { id, principal_balance: balance };
    apiGet('interest_api.php?action=view&id=' + id).then(d => {
        int_currentCustomer = d.customer;
        const suggested = (parseFloat(d.customer.principal) * parseFloat(d.customer.rate_of_interest) / 100).toFixed(2);
        document.getElementById('int_collectMode').value = 'interest';
        document.getElementById('int_collectCustomerId').value = id;
        document.getElementById('int_collectTitle').textContent = 'Interest Payment (Auto-calculated)';
        document.getElementById('int_collectCustomerBox').innerHTML = `
            <b>Name:</b> ${d.customer.name} &nbsp; <b>Village:</b> ${d.customer.village} &nbsp; <b>Mobile:</b> ${d.customer.mobile}<br>
            <b>Principal:</b> ${d.customer.principal} &nbsp; <b>Rate of Interest:</b> ${d.customer.rate_of_interest}%
            &nbsp; <b>Total Paid Interest:</b> ${d.customer.total_interest_collected}`;
        document.getElementById('int_collectAmount').value = suggested;
        document.getElementById('int_collectDate').value = new Date().toISOString().slice(0,10);
        openModal('int_collectModal');
    });
}

function int_submitCollect(andPrint) {
    const mode = document.getElementById('int_collectMode').value;
    const id = document.getElementById('int_collectCustomerId').value;
    const amount = document.getElementById('int_collectAmount').value;
    const date = document.getElementById('int_collectDate').value;
    const action = mode === 'interest' ? 'collect_interest' : 'collect_principal';

    apiPost(`interest_api.php?action=${action}`, { id, amount, date }).then(res => {
        if (res.success) {
            closeModal('int_collectModal');
            closeModal('int_viewModal');
            int_loadTable();
            if (andPrint) printSectionHtml(`<h3>${mode === 'interest' ? 'Interest' : 'Principal'} Collection Receipt</h3>
                <p>Amount: ${amount}<br>Date: ${date}<br>Status: ${res.status || ''}</p>`);
        } else alert(res.message || 'Failed');
    });
}

function int_printRow(id) {
    apiGet('interest_api.php?action=view&id=' + id).then(d => {
        const c = d.customer;
        printSectionHtml(`<h3>Interest Customer</h3>
            <p>ID: ${c.id}<br>Name: ${c.name}<br>Village: ${c.village}<br>Mobile: ${c.mobile}<br>
            Principal: ${c.principal}<br>Principal Balance: ${c.principal_balance}<br>
            Rate of Interest: ${c.rate_of_interest}%<br>Date: ${c.transaction_date}<br>
            No. of Payments: ${c.no_of_payments}<br>Total Interest Collected: ${c.total_interest_collected}</p>`);
    });
}

int_loadVillages();
int_loadTable();

// ================= BORROWER MODULE =================
let bor_currentCustomer = null;

function bor_loadVillages() {
    apiGet('borrower_api.php?action=villages').then(d => {
        const sel = document.getElementById('bor_villageFilter');
        sel.innerHTML = '<option value="">All Villages</option>';
        d.villages.forEach(v => {
            const o = document.createElement('option'); o.value = v; o.textContent = v;
            sel.appendChild(o);
        });
    });
}

function bor_loadTable() {
    const q = document.getElementById('bor_searchBox').value;
    const village = document.getElementById('bor_villageFilter').value;
    apiGet(`borrower_api.php?action=list&q=${encodeURIComponent(q)}&village=${encodeURIComponent(village)}`).then(d => {
        const body = document.getElementById('bor_tableBody');
        body.innerHTML = '';
        if (!d.rows.length) { body.innerHTML = '<tr><td colspan="9">No records found.</td></tr>'; return; }
        d.rows.forEach(r => {
            const payDisabled = parseFloat(r.balance) >= parseFloat(r.principal) ? 'disabled' : '';
            body.innerHTML += `<tr>
                <td>${r.id}</td><td>${r.name}</td><td>${r.village}</td><td>${r.mobile}</td>
                <td>${r.principal}</td><td>${r.balance}</td><td>${r.due_count}</td><td>${r.day_count}</td>
                <td class="actions">
                    <button class="btn btn-view" onclick="bor_viewCustomer(${r.id})">View</button>
                    <button class="btn btn-pay" ${payDisabled} onclick="bor_viewCustomer(${r.id}, true)">Pay</button>
                    <button class="btn btn-print" onclick="bor_printRow(${r.id})">Print</button>
                </td>
            </tr>`;
        });
    });
}

document.getElementById('bor_searchBox').addEventListener('input', debounce(bor_loadTable, 350));
document.getElementById('bor_villageFilter').addEventListener('change', bor_loadTable);
setupVoiceSearch('bor_micBtn', 'bor_searchBox');

function bor_submitAdd(andPrint) {
    const f = document.getElementById('bor_addForm');
    const data = Object.fromEntries(new FormData(f).entries());
    apiPost('borrower_api.php?action=add', data).then(res => {
        if (res.success) {
            closeModal('bor_addModal'); f.reset(); bor_loadTable(); bor_loadVillages();
            if (andPrint) printSectionHtml(`<h3>New Borrower Record</h3>
                <p>Name: ${data.name}<br>Village: ${data.village}<br>Mobile: ${data.mobile}<br>
                Principal: ${data.principal}<br>Date: ${data.transaction_date}</p>`);
        } else alert(res.message || 'Failed to save.');
    });
}

function bor_viewCustomer(id, goToPay) {
    apiGet('borrower_api.php?action=view&id=' + id).then(d => {
        if (!d.success) { alert('Not found'); return; }
        bor_currentCustomer = d.customer;
        document.getElementById('bor_viewCustomerBox').innerHTML = `
            <b>Name:</b> ${d.customer.name} &nbsp; <b>Village:</b> ${d.customer.village} &nbsp; <b>Mobile:</b> ${d.customer.mobile}<br>
            <b>Principal:</b> ${d.customer.principal} &nbsp; <b>Collected:</b> ${d.customer.balance}
            &nbsp; <b>Pending:</b> ${d.customer.pending_amount}`;

        let h = '<table><tr><th>Date</th><th>Amount</th><th>Status</th></tr>';
        d.history.forEach(r => h += `<tr><td>${r.collection_date}</td><td>${r.amount}</td>
            <td><span class="badge ${r.status}">${r.status}</span></td></tr>`);
        h += '</table>';
        document.getElementById('bor_historyBox').innerHTML = h || 'No records';

        bor_showTab('bor_tabDetails', document.querySelector('#bor_viewModal .tab-buttons button'));
        if (goToPay) { closeModal('bor_viewModal'); bor_openPayModal(); }
        else openModal('bor_viewModal');
    });
}

function bor_showTab(tabId, btn) {
    document.querySelectorAll('#bor_viewModal .tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('#bor_viewModal .tab-buttons button').forEach(b => b.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    btn.classList.add('active');
}

function bor_openPayModal() {
    document.getElementById('bor_payCustomerId').value = bor_currentCustomer.id;
    document.getElementById('bor_payCustomerBox').innerHTML = `
        <b>Name:</b> ${bor_currentCustomer.name} &nbsp; <b>Village:</b> ${bor_currentCustomer.village} &nbsp; <b>Mobile:</b> ${bor_currentCustomer.mobile}<br>
        <b>Principal:</b> ${bor_currentCustomer.principal} &nbsp; <b>Collected:</b> ${bor_currentCustomer.balance}
        &nbsp; <b>Pending:</b> ${bor_currentCustomer.pending_amount}`;
    document.getElementById('bor_payAmount').value = bor_currentCustomer.suggested_due;
    document.getElementById('bor_payDate').value = new Date().toISOString().slice(0,10);
    openModal('bor_payModal');
}

function bor_submitPay(andPrint) {
    const id = document.getElementById('bor_payCustomerId').value;
    const amount = document.getElementById('bor_payAmount').value;
    const date = document.getElementById('bor_payDate').value;
    apiPost('borrower_api.php?action=pay_due', { id, amount, date }).then(res => {
        if (res.success) {
            closeModal('bor_payModal'); closeModal('bor_viewModal'); bor_loadTable();
            if (andPrint) printSectionHtml(`<h3>Due Payment Receipt</h3><p>Amount: ${amount}<br>Date: ${date}</p>`);
        } else alert(res.message || 'Failed');
    });
}

function bor_printRow(id) {
    apiGet('borrower_api.php?action=view&id=' + id).then(d => {
        const c = d.customer;
        printSectionHtml(`<h3>Borrower</h3><p>ID: ${c.id}<br>Name: ${c.name}<br>Village: ${c.village}<br>
            Mobile: ${c.mobile}<br>Principal: ${c.principal}<br>Balance: ${c.balance}<br>
            Due Count: ${c.due_count}<br>Day Count: ${c.day_count}</p>`);
    });
}

bor_loadVillages();
bor_loadTable();

// ================= RENT MODULE =================
let rnt_currentCustomer = null;

function rnt_loadVillages() {
    apiGet('rent_api.php?action=villages').then(d => {
        const sel = document.getElementById('rnt_villageFilter');
        sel.innerHTML = '<option value="">All Villages</option>';
        d.villages.forEach(v => {
            const o = document.createElement('option'); o.value = v; o.textContent = v;
            sel.appendChild(o);
        });
    });
}

function rnt_loadTable() {
    const q = document.getElementById('rnt_searchBox').value;
    const village = document.getElementById('rnt_villageFilter').value;
    apiGet(`rent_api.php?action=list&q=${encodeURIComponent(q)}&village=${encodeURIComponent(village)}`).then(d => {
        const body = document.getElementById('rnt_tableBody');
        body.innerHTML = '';
        if (!d.rows.length) { body.innerHTML = '<tr><td colspan="8">No records found.</td></tr>'; return; }
        d.rows.forEach(r => {
            const payDisabled = r.status === 'paid' ? 'disabled' : '';
            body.innerHTML += `<tr>
                <td>${r.id}</td><td>${r.name}</td><td>${r.village}</td><td>${r.mobile}</td>
                <td>${r.rent_amount}</td><td>${r.agreement_date}</td>
                <td><span class="badge ${r.status}">${r.status}</span></td>
                <td class="actions">
                    <button class="btn btn-view" onclick="rnt_viewCustomer(${r.id})">View</button>
                    <button class="btn btn-pay" ${payDisabled} onclick="rnt_openPayModal(${r.id})">Pay Rent</button>
                    <button class="btn btn-print" onclick="rnt_printRow(${r.id})">Print</button>
                </td>
            </tr>`;
        });
    });
}

document.getElementById('rnt_searchBox').addEventListener('input', debounce(rnt_loadTable, 350));
document.getElementById('rnt_villageFilter').addEventListener('change', rnt_loadTable);
setupVoiceSearch('rnt_micBtn', 'rnt_searchBox');

function rnt_submitAdd(andPrint) {
    const f = document.getElementById('rnt_addForm');
    const data = Object.fromEntries(new FormData(f).entries());
    apiPost('rent_api.php?action=add', data).then(res => {
        if (res.success) {
            closeModal('rnt_addModal'); f.reset(); rnt_loadTable(); rnt_loadVillages();
            if (andPrint) printSectionHtml(`<h3>New Rent Record</h3>
                <p>Name: ${data.name}<br>Village: ${data.village}<br>Mobile: ${data.mobile}<br>
                Rent Amount: ${data.rent_amount}<br>Agreement Date: ${data.agreement_date}</p>`);
        } else alert(res.message || 'Failed to save.');
    });
}

function rnt_viewCustomer(id) {
    apiGet('rent_api.php?action=view&id=' + id).then(d => {
        if (!d.success) { alert('Not found'); return; }
        rnt_currentCustomer = d.customer;
        document.getElementById('rnt_viewCustomerBox').innerHTML = `
            <b>Name:</b> ${d.customer.name} &nbsp; <b>Village:</b> ${d.customer.village} &nbsp; <b>Mobile:</b> ${d.customer.mobile}<br>
            <b>Rent Amount:</b> ${d.customer.rent_amount} &nbsp; <b>Agreement Date:</b> ${d.customer.agreement_date}
            &nbsp; <b>Status:</b> <span class="badge ${d.customer.status}">${d.customer.status}</span>`;
        let h = '<table><tr><th>Date</th><th>Amount</th></tr>';
        d.history.forEach(r => h += `<tr><td>${r.payment_date}</td><td>${r.amount}</td></tr>`);
        h += '</table>';
        document.getElementById('rnt_historyBox').innerHTML = h || 'No payments recorded';
        openModal('rnt_viewModal');
    });
}

function rnt_openPayModal(id) {
    apiGet('rent_api.php?action=view&id=' + id).then(d => {
        rnt_currentCustomer = d.customer;
        document.getElementById('rnt_payCustomerId').value = id;
        document.getElementById('rnt_payCustomerBox').innerHTML = `
            <b>Name:</b> ${d.customer.name} &nbsp; <b>Village:</b> ${d.customer.village} &nbsp; <b>Mobile:</b> ${d.customer.mobile}<br>
            <b>Rent Amount:</b> ${d.customer.rent_amount}`;
        document.getElementById('rnt_payAmount').value = d.customer.rent_amount;
        document.getElementById('rnt_payDate').value = new Date().toISOString().slice(0,10);
        openModal('rnt_payModal');
    });
}

function rnt_submitPay(andPrint) {
    const id = document.getElementById('rnt_payCustomerId').value;
    const amount = document.getElementById('rnt_payAmount').value;
    const date = document.getElementById('rnt_payDate').value;
    apiPost('rent_api.php?action=pay', { id, amount, date }).then(res => {
        if (res.success) {
            closeModal('rnt_payModal'); rnt_loadTable();
            if (andPrint) printSectionHtml(`<h3>Rent Payment Receipt</h3><p>Amount: ${amount}<br>Date: ${date}</p>`);
        } else alert(res.message || 'Failed');
    });
}

function rnt_printRow(id) {
    apiGet('rent_api.php?action=view&id=' + id).then(d => {
        const c = d.customer;
        printSectionHtml(`<h3>Rent Record</h3><p>ID: ${c.id}<br>Name: ${c.name}<br>Village: ${c.village}<br>
            Mobile: ${c.mobile}<br>Rent Amount: ${c.rent_amount}<br>Agreement Date: ${c.agreement_date}<br>
            Status: ${c.status}</p>`);
    });
}

rnt_loadVillages();
rnt_loadTable();

// ================= MOI MODULE =================
let moi_allRows = [];

function moi_loadVillages() {
    apiGet('moi_api.php?action=villages').then(d => {
        const sel = document.getElementById('moi_villageFilter');
        sel.innerHTML = '<option value="">All Villages (English)</option>';
        d.villages.forEach(v => {
            const o = document.createElement('option'); o.value = v; o.textContent = v;
            sel.appendChild(o);
        });
    });
}

function moi_loadTable() {
    const q = document.getElementById('moi_searchBox').value;
    const village = document.getElementById('moi_villageFilter').value;
    apiGet(`moi_api.php?action=list&q=${encodeURIComponent(q)}&village=${encodeURIComponent(village)}`).then(d => {
        moi_allRows = d.rows;
        moi_renderTable();
    });
}

function moi_renderTable() {
    const body = document.getElementById('moi_tableBody');
    body.innerHTML = '';
    if (!moi_allRows.length) { body.innerHTML = '<tr><td colspan="13">No records found.</td></tr>'; return; }
    moi_allRows.forEach(r => {
        body.innerHTML += `<tr data-id="${r.id}">
            <td>${r.id}</td>
            <td class="editable" data-field="name_tamil">${r.name_tamil ?? ''}</td>
            <td class="editable" data-field="name_english">${r.name_english ?? ''}</td>
            <td class="editable" data-field="village_tamil">${r.village_tamil ?? ''}</td>
            <td class="editable" data-field="village_english">${r.village_english ?? ''}</td>
            <td class="editable" data-field="mobile">${r.mobile ?? ''}</td>
            <td class="editable" data-field="alternate_mobile">${r.alternate_mobile ?? ''}</td>
            <td class="editable" data-field="city">${r.city ?? ''}</td>
            <td class="editable" data-field="income">${r.income ?? ''}</td>
            <td class="editable" data-field="expenditure">${r.expenditure ?? ''}</td>
            <td class="editable" data-field="information">${r.information ?? ''}</td>
            <td>${r.up_dated ?? ''}</td>
            <td class="actions">
                <button class="btn btn-edit" onclick="moi_toggleEdit(${r.id}, this)">Edit</button>
            </td>
        </tr>`;
    });
}

document.getElementById('moi_searchBox').addEventListener('input', debounce(moi_loadTable, 350));
document.getElementById('moi_villageFilter').addEventListener('change', moi_loadTable);
setupVoiceSearch('moi_micBtn', 'moi_searchBox');

// ---------------- Column sort (click header) ----------------
let moi_sortAsc = {};
document.querySelectorAll('#moi_moiTable th.sortable').forEach(th => {
    th.addEventListener('click', () => {
        const col = parseInt(th.dataset.col);
        moi_sortAsc[col] = !moi_sortAsc[col];
        sortTableByColumn(document.getElementById('moi_moiTable'), col, moi_sortAsc[col]);
    });
});

// ---------------- Inline Edit ----------------
function moi_toggleEdit(id, btn) {
    const row = document.querySelector(`tr[data-id="${id}"]`);
    const isEditing = btn.textContent === 'Save/Cancel';
    if (btn.dataset.mode === 'edit') return; // already editing

    btn.dataset.mode = 'edit';
    const cells = row.querySelectorAll('.editable');
    const original = {};
    cells.forEach(c => {
        original[c.dataset.field] = c.textContent;
        const val = c.textContent;
        c.innerHTML = `<input type="text" value="${val.replace(/"/g,'&quot;')}" style="width:100%;padding:4px;">`;
    });
    const actionsTd = btn.parentElement;
    actionsTd.innerHTML = `
        <button class="btn btn-save" onclick="moi_saveEdit(${id})">Save</button>
        <button class="btn btn-cancel" onclick="moi_cancelEdit(${id})">Cancel</button>`;
    row.dataset.original = JSON.stringify(original);
}

function moi_cancelEdit(id) {
    moi_renderTable(); // simplest: reload from cached moi_allRows (discards unsaved edits)
}

function moi_saveEdit(id) {
    const row = document.querySelector(`tr[data-id="${id}"]`);
    const data = { id };
    row.querySelectorAll('.editable').forEach(c => {
        data[c.dataset.field] = c.querySelector('input').value;
    });
    apiPost('moi_api.php?action=update', data).then(res => {
        if (res.success) moi_loadTable();
        else alert(res.message || 'Update failed');
    });
}

// ---------------- Add ----------------
function moi_submitAdd() {
    const f = document.getElementById('moi_addForm');
    const data = Object.fromEntries(new FormData(f).entries());
    apiPost('moi_api.php?action=add', data).then(res => {
        if (res.success) { closeModal('moi_addModal'); f.reset(); moi_loadTable(); moi_loadVillages(); }
        else alert(res.message || 'Failed to save.');
    });
}

// ---------------- Print PDF (name_tamil, village_tamil, income, expenditure only) ----------------
function moi_printPDF() {
    const q = document.getElementById('moi_searchBox').value;
    const village = document.getElementById('moi_villageFilter').value;
    window.open(`print/print_moi.php?q=${encodeURIComponent(q)}&village=${encodeURIComponent(village)}`, '_blank');
}

moi_loadVillages();
moi_loadTable();
</script>
</body>
</html>
