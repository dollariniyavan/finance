<?php
require_once 'config.php';
$db = getDB();
$action = $_REQUEST['action'] ?? '';

switch ($action) {

    case 'list': {
        $q = trim($_GET['q'] ?? '');
        $village = trim($_GET['village'] ?? '');
        $sql = "SELECT rc.*,
                    (SELECT MAX(rp.payment_date) FROM rent_payments rp WHERE rp.customer_id = rc.id) AS last_payment_date
                FROM rent_customers rc WHERE 1=1";
        $params = []; $types = '';
        if ($q !== '') {
            $sql .= " AND (rc.id LIKE ? OR rc.name LIKE ? OR rc.village LIKE ? OR rc.mobile LIKE ?
                       OR rc.rent_amount LIKE ? OR rc.agreement_date LIKE ? OR rc.status LIKE ?)";
            $like = "%$q%";
            for ($i=0;$i<7;$i++) { $params[] = $like; $types .= 's'; }
        }
        if ($village !== '') { $sql .= " AND rc.village = ?"; $params[] = $village; $types .= 's'; }
        $sql .= " ORDER BY rc.id DESC";
        $stmt = $db->prepare($sql);
        if ($params) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        // Monthly rent cycle: 'paid' only if the last payment falls in the current
        // calendar month; otherwise it's 'pending' again (auto re-enables each month).
        $currentMonth = date('Y-m');
        foreach ($rows as &$r) {
            $paidThisMonth = $r['last_payment_date'] && substr($r['last_payment_date'], 0, 7) === $currentMonth;
            $r['status'] = $paidThisMonth ? 'paid' : 'pending';
        }
        json_out(['rows' => $rows]);
    }

    case 'villages': {
        $res = $db->query("SELECT DISTINCT village FROM rent_customers ORDER BY village ASC");
        json_out(['villages' => array_map(fn($r) => $r['village'], $res->fetch_all(MYSQLI_ASSOC))]);
    }

    case 'add': {
        $name = trim($_POST['name'] ?? '');
        $village = trim($_POST['village'] ?? '');
        $mobile = trim($_POST['mobile'] ?? '');
        $rent_amount = floatval($_POST['rent_amount'] ?? 0);
        $date = $_POST['agreement_date'] ?? date('Y-m-d');

        if ($name === '' || $mobile === '' || $rent_amount <= 0) {
            json_out(['success' => false, 'message' => 'Name, mobile and rent amount are required.']);
        }
        $stmt = $db->prepare("INSERT INTO rent_customers (name,village,mobile,rent_amount,agreement_date,status)
            VALUES (?,?,?,?,?,'pending')");
        $stmt->bind_param('sssds', $name,$village,$mobile,$rent_amount,$date);
        $ok = $stmt->execute();
        json_out(['success' => $ok, 'id' => $db->insert_id, 'message' => $ok ? 'Saved successfully.' : $db->error]);
    }

    case 'view': {
        $id = intval($_GET['id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM rent_customers WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $customer = $stmt->get_result()->fetch_assoc();
        if (!$customer) json_out(['success'=>false,'message'=>'Not found']);

        $stmt2 = $db->prepare("SELECT * FROM rent_payments WHERE customer_id=? ORDER BY payment_date DESC");
        $stmt2->bind_param('i', $id);
        $stmt2->execute();
        $history = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);

        $currentMonth = date('Y-m');
        $lastPaymentDate = $history[0]['payment_date'] ?? null;
        $customer['status'] = ($lastPaymentDate && substr($lastPaymentDate, 0, 7) === $currentMonth) ? 'paid' : 'pending';

        json_out(['success'=>true,'customer'=>$customer,'history'=>$history]);
    }

    case 'pay': {
        $id = intval($_POST['id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $date = $_POST['date'] ?? date('Y-m-d');
        if ($id <= 0 || $amount <= 0) json_out(['success'=>false,'message'=>'Invalid data']);

        // Rent is collected once per calendar month; block a second collection
        // in the same month the payment date falls in.
        $monthOfPayment = substr($date, 0, 7);
        $stmt0 = $db->prepare("SELECT MAX(payment_date) AS last_date FROM rent_payments WHERE customer_id=?");
        $stmt0->bind_param('i', $id);
        $stmt0->execute();
        $lastDate = $stmt0->get_result()->fetch_assoc()['last_date'] ?? null;
        if ($lastDate && substr($lastDate, 0, 7) === $monthOfPayment) {
            json_out(['success'=>false, 'message'=>'Rent for this month has already been collected.']);
        }

        $stmt = $db->prepare("INSERT INTO rent_payments (customer_id, payment_date, amount) VALUES (?,?,?)");
        $stmt->bind_param('isd', $id, $date, $amount);
        $ok = $stmt->execute();
        if ($ok) $db->query("UPDATE rent_customers SET status='paid' WHERE id=$id");
        json_out(['success'=>$ok, 'message'=>$ok?'Rent payment recorded.':$db->error]);
    }

    default:
        json_out(['error' => 'Unknown action']);
}
