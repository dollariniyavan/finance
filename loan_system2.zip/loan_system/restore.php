<?php
// ==========================================================
// DATABASE RESTORE — accepts an uploaded .sql file (such as
// one produced by backup.php) and executes it statement by
// statement against the configured database.
//
// WARNING: this runs arbitrary SQL from the uploaded file.
// Only use this with backup files you trust (e.g. your own
// exports from backup.php), since it has full access to the
// database.
// ==========================================================
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_FILES['sql_file']) || $_FILES['sql_file']['error'] !== UPLOAD_ERR_OK) {
    json_out(['success' => false, 'message' => 'No file uploaded or upload error.']);
}

$tmpPath = $_FILES['sql_file']['tmp_name'];
$ext = strtolower(pathinfo($_FILES['sql_file']['name'], PATHINFO_EXTENSION));
if ($ext !== 'sql') {
    json_out(['success' => false, 'message' => 'Please upload a .sql file.']);
}

$sql = file_get_contents($tmpPath);
if ($sql === false || trim($sql) === '') {
    json_out(['success' => false, 'message' => 'Could not read the uploaded file.']);
}

$db = getDB();
$db->autocommit(false);

try {
    if (!$db->multi_query($sql)) {
        throw new Exception($db->error);
    }
    // multi_query runs statements one at a time; drain all results
    // (freeing any result sets) so an error on a later statement
    // surfaces before we commit.
    do {
        if ($result = $db->store_result()) {
            $result->free();
        }
        if ($db->error) throw new Exception($db->error);
        if ($db->more_results()) {
            $db->next_result();
        } else {
            break;
        }
    } while (true);

    $db->commit();
    json_out(['success' => true, 'message' => 'Database restored successfully.']);
} catch (Exception $e) {
    $db->rollback();
    json_out(['success' => false, 'message' => 'Restore failed: ' . $e->getMessage()]);
} finally {
    $db->autocommit(true);
}
