<?php
require_once 'config.php';
$db = getDB();
$action = $_REQUEST['action'] ?? '';

// installment count based on schedule type
function installmentCount($type) {
    switch ($type) {
        case '100days': return 100;
        case '10weeks': return 10;
        case 'monthly': return 5; // up to five months
        default: return 100;
    }
}

switch ($action) {

    case 'list': {
        $q = trim($_GET['q'] ?? '');
        $village = trim($_GET['village'] ?? '');
        $sql = "SELECT * FROM borrower_customers WHERE 1=1";
        $params = []; $types = '';
        if ($q !== '') {
            $sql .= " AND (id LIKE ? OR name LIKE ? OR village LIKE ? OR mobile LIKE ?
                       OR principal LIKE ? OR balance LIKE ? OR due_count LIKE ? OR day_count LIKE ?)";
            $like = "%$q%";
            for ($i=0;$i<8;$i++) { $params[] = $like; $types .= 's'; }
        }
        if ($village !== '') { $sql .= " AND village = ?"; $params[] = $village; $types .= 's'; }
        $sql .= " ORDER BY id DESC";
        $stmt = $db->prepare($sql);
        if ($params) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        // refresh day_count dynamically (days elapsed since transaction date)
        foreach ($rows as &$r) {
            $r['day_count'] = (int)((strtotime('today') - strtotime($r['transaction_date'])) / 86400);
        }
        json_out(['rows' => $rows]);
    }

    case 'villages': {
        $res = $db->query("SELECT DISTINCT village FROM borrower_customers ORDER BY village ASC");
        $list = array_map(fn($r) => $r['village'], $res->fetch_all(MYSQLI_ASSOC));
        json_out(['villages' => $list]);
    }

    case 'add': {
        $name = trim($_POST['name'] ?? '');
        $village = trim($_POST['village'] ?? '');
        $mobile = trim($_POST['mobile'] ?? '');
        $principal = floatval($_POST['principal'] ?? 0);
        $date = $_POST['transaction_date'] ?? date('Y-m-d');
        $payment_type = $_POST['payment_type'] ?? '100days';

        if ($name === '' || $mobile === '' || $principal <= 0) {
            json_out(['success' => false, 'message' => 'Name, mobile and principal are required.']);
        }
        $stmt = $db->prepare("INSERT INTO borrower_customers
            (name,village,mobile,principal,balance,transaction_date,payment_type,due_count,day_count)
            VALUES (?,?,?,?,0,?,?,0,0)");
        $stmt->bind_param('sssdss', $name,$village,$mobile,$principal,$date,$payment_type);
        $ok = $stmt->execute();
        json_out(['success' => $ok, 'id' => $db->insert_id, 'message' => $ok ? 'Saved successfully.' : $db->error]);
    }

    case 'view': {
        $id = intval($_GET['id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM borrower_customers WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $customer = $stmt->get_result()->fetch_assoc();
        if (!$customer) json_out(['success'=>false,'message'=>'Not found']);

        $stmt2 = $db->prepare("SELECT * FROM borrower_collections WHERE customer_id=? ORDER BY collection_date DESC");
        $stmt2->bind_param('i', $id);
        $stmt2->execute();
        $history = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);

        $customer['pending_amount'] = $customer['principal'] - $customer['balance'];
        $customer['suggested_due'] = round($customer['principal'] / installmentCount($customer['payment_type']), 2);

        json_out(['success'=>true,'customer'=>$customer,'history'=>$history]);
    }

    case 'pay_due': {
        $id = intval($_POST['id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $date = $_POST['date'] ?? date('Y-m-d');

        if ($id <= 0 || $amount <= 0) json_out(['success'=>false,'message'=>'Invalid data']);

        $stmt = $db->prepare("SELECT principal, balance FROM borrower_customers WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if (!$row) json_out(['success'=>false,'message'=>'Not found']);

        $newBalance = $row['balance'] + $amount;
        if ($newBalance > $row['principal']) $newBalance = $row['principal'];
        $status = ($newBalance >= $row['principal']) ? 'complete' : 'partial';

        $stmt2 = $db->prepare("INSERT INTO borrower_collections (customer_id, collection_date, amount, status) VALUES (?,?,?,?)");
        $stmt2->bind_param('isds', $id, $date, $amount, $status);
        $ok = $stmt2->execute();

        if ($ok) {
            $stmt3 = $db->prepare("UPDATE borrower_customers SET balance=?, due_count = due_count + 1 WHERE id=?");
            $stmt3->bind_param('di', $newBalance, $id);
            $stmt3->execute();
        }
        json_out(['success'=>$ok, 'message'=>$ok?'Due collected.':$db->error]);
    }

    default:
        json_out(['error' => 'Unknown action']);
}
