// ==========================================================
// COMMON HELPERS: AJAX debounce search, Tamil voice search,
// modal open/close, generic fetch wrapper
// ==========================================================

function debounce(fn, delay) {
    let t;
    return function (...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), delay);
    };
}

// Generic modal open/close
function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }

// Generic POST helper returning parsed JSON
async function apiPost(url, dataObj) {
    const fd = new FormData();
    for (const k in dataObj) fd.append(k, dataObj[k]);
    const res = await fetch(url, { method: 'POST', body: fd });
    return res.json();
}
async function apiGet(url) {
    const res = await fetch(url);
    return res.json();
}

// ----------------------------------------------------------
// Print helpers shared by every module: print any on-screen
// section (by element id) or an arbitrary HTML snippet in a
// new browser tab, ready for "Save as PDF".
// ----------------------------------------------------------
function printSection(elId, title) {
    printSectionHtml(`<h3>${title}</h3>${document.getElementById(elId).innerHTML}`);
}
function printSectionHtml(html) {
    const w = window.open('', '_blank', 'width=600,height=700');
    w.document.write(`<html><head><title>Print</title>
        <link rel="stylesheet" href="assets/style.css"></head><body>${html}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 300);
}

// ----------------------------------------------------------
// Voice search (Tamil) using Web Speech API.
// Attaches to a mic button; writes recognized text into the
// given input field id, then triggers the input's 'input' event
// so the existing debounce-search logic fires automatically.
// ----------------------------------------------------------
function setupVoiceSearch(micBtnId, inputId) {
    const micBtn = document.getElementById(micBtnId);
    const input = document.getElementById(inputId);
    if (!micBtn || !input) return;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        micBtn.title = 'Voice search not supported in this browser';
        micBtn.disabled = true;
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'ta-IN'; // Tamil (India)
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    micBtn.addEventListener('click', () => {
        micBtn.classList.add('listening');
        recognition.start();
    });

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        input.value = transcript;
        input.dispatchEvent(new Event('input'));
    };
    recognition.onerror = () => { micBtn.classList.remove('listening'); };
    recognition.onend = () => { micBtn.classList.remove('listening'); };
}

// ----------------------------------------------------------
// Column sort helper for the MOI table (client-side click-to-sort)
// ----------------------------------------------------------
function sortTableByColumn(table, colIndex, asc) {
    const tbody = table.tBodies[0];
    const rows = Array.from(tbody.querySelectorAll('tr'));
    rows.sort((a, b) => {
        const av = a.children[colIndex].innerText.trim().toLowerCase();
        const bv = b.children[colIndex].innerText.trim().toLowerCase();
        const an = parseFloat(av), bn = parseFloat(bv);
        if (!isNaN(an) && !isNaN(bn)) return asc ? an - bn : bn - an;
        return asc ? av.localeCompare(bv, 'ta') : bv.localeCompare(av, 'ta');
    });
    rows.forEach(r => tbody.appendChild(r));
}
