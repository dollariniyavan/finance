# Loan / Rent / MOI Management System (PHP + MySQL) — Single Page

## What's included
- `database.sql` — full database structure (import this first)
- `config.php` — edit your DB host/user/password/name here
- **`index.php`** — the entire app: a persistent top navigation bar (Interest, Borrower, House Rent, MOI, plus a Backup/Restore shortcut) with all four modules on one page. Switching between them is instant (no page reload, no separate dashboard to click back to) via a `showPage()` JS router.
- `interest_api.php`, `borrower_api.php`, `rent_api.php`, `moi_api.php` — backend endpoints called by AJAX from `index.php`
- `backup.php` — streams a full `.sql` dump (structure + data) of the database for download
- `restore.php` — accepts an uploaded `.sql` file and restores it into the database
- `print/print_moi.php` — printable MOI report (Name Tamil, Village Tamil, Income, Expenditure only)
- `assets/style.css`, `assets/common.js` — shared styling + AJAX/voice-search/print helpers

## Setup
1. Install a local server stack (XAMPP / WAMP / LAMP) with PHP 8+ and MySQL.
2. Import `database.sql` into MySQL:
   ```
   mysql -u root -p < database.sql
   ```
   If you already have an existing database from a previous version, run the `ALTER TABLE` statements at the bottom of `database.sql` instead (they add `interest_principal_collections.status` and `moi_records.alternate_mobile`).
3. Open `config.php` and set `DB_HOST`, `DB_USER`, `DB_PASS`, `DB_NAME`.
4. Copy the `loan_system` folder into your server's web root (e.g. `htdocs/loan_system`).
5. Visit `http://localhost/loan_system/index.php`.

## Navigation (no more dashboard)
There's no separate dashboard page anymore. A dark navigation bar is pinned to the top of every screen with four buttons — 💰 Interest, 🤝 Borrower, 🏠 House Rent, 📇 MOI/Details — plus a 🗄 Backup/Restore shortcut on the right. Clicking any of them switches instantly (`showPage('interest')`, etc.) without a page reload; the active module is highlighted in the nav bar. The app opens on the Interest page by default.

All four modules' markup and JavaScript live in `index.php`, each inside its own `<section id="page-interest">`, `<section id="page-borrower">`, etc. Every element ID and JS function is namespaced per module (`int_...`, `bor_...`, `rnt_...`, `moi_...`) so the four modules never collide even though they're all on the same page. Shared utilities (AJAX helpers, voice search, print, modal open/close) live once in `assets/common.js`.

## Database Backup / Restore
Click **🗄 Backup / Restore** in the nav bar from any page:
- **Backup** — downloads a `.sql` file containing `DROP TABLE`/`CREATE TABLE`/`INSERT` statements for every table, generated in pure PHP (no `mysqldump` or shell access required, so it works on restricted hosting too).
- **Restore** — upload a `.sql` file (your own backup, or `database.sql`) and it's executed against the live database. This **overwrites** any existing tables with the same names, so only restore files you trust. Note: MySQL implicitly commits on `DROP TABLE`/`CREATE TABLE`, so a restore isn't fully all-or-nothing if it fails partway through — always take a fresh backup before restoring.
- If large backups fail to upload, raise `upload_max_filesize` and `post_max_size` in your `php.ini`.

## Recent changes in this version
- **Removed the dashboard concept** — replaced with a persistent top nav bar (four module icons + Backup/Restore) visible on every page.
- **Added Database Backup / Restore** (`backup.php`, `restore.php`), accessible from the nav bar on any page.
- **MOI** — "Alternate Mobile" column: searchable, sortable, editable inline, and included in the "Add New Record" popup.
- **Interest** — "Payment Schedule" removed from the Add popup; Transaction Date defaults to today. Interest amount (row Pay button and the "Interest Collection" button inside View) auto-calculates as `principal × rate%`. Payment status (partial/complete) is automatic based on `principal_balance`. Principal Collection history now shows a status badge too.
- **Borrower** — Add popup date defaults to today; "Pay Due" button removed from the View window (use the row-level Pay button, which opens the payment form directly).
- **Rent** — "Pay Rent" disables once collected for the current month and re-enables automatically at the start of the next month.

## Notes / things to customize
- Monetary calculations live in `*_api.php` — adjust formulas there if your business rules differ.
- Voice search relies on the browser's built-in Web Speech API (`ta-IN`); needs Chrome/Edge and an internet connection for the recognition service.
- Print buttons open a new tab and call `window.print()`; choose "Save as PDF" in the print dialog for a PDF file.
- DB credentials are in plain `config.php` — for production, restrict file permissions or use environment variables. Also consider restricting or removing `backup.php`/`restore.php` access (e.g. behind a login) before deploying publicly, since they expose full database contents/control.
