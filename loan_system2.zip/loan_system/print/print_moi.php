<?php
require_once '../config.php';
$db = getDB();
$q = trim($_GET['q'] ?? '');
$village = trim($_GET['village'] ?? '');

$sql = "SELECT name_tamil, village_tamil, income, expenditure FROM moi_records WHERE 1=1";
$params = []; $types = '';
if ($q !== '') {
    $sql .= " AND (name_tamil LIKE ? OR name_english LIKE ? OR village_tamil LIKE ? OR village_english LIKE ?
               OR mobile LIKE ? OR city LIKE ?)";
    $like = "%$q%";
    for ($i=0;$i<6;$i++) { $params[] = $like; $types .= 's'; }
}
if ($village !== '') { $sql .= " AND village_english = ?"; $params[] = $village; $types .= 's'; }
$sql .= " ORDER BY id DESC";
$stmt = $db->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ta">
<head>
<meta charset="UTF-8">
<title>MOI Report - Print</title>
<style>
    body { font-family: 'Noto Sans Tamil', Arial, sans-serif; margin: 30px; }
    h2 { text-align: center; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { border: 1px solid #444; padding: 8px; text-align: left; font-size: 13px; }
    th { background: #eee; }
    .print-btn { margin-bottom: 16px; }
    @media print { .print-btn { display: none; } }
</style>
</head>
<body>
<button class="print-btn" onclick="window.print()">🖨 Print / Save as PDF</button>
<h2>MOI Report</h2>
<table>
    <tr><th>Name (Tamil)</th><th>Village (Tamil)</th><th>Income</th><th>Expenditure</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
        <td><?= h($r['name_tamil']) ?></td>
        <td><?= h($r['village_tamil']) ?></td>
        <td><?= h($r['income']) ?></td>
        <td><?= h($r['expenditure']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>
