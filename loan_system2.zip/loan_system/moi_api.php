<?php
require_once 'config.php';
$db = getDB();
$action = $_REQUEST['action'] ?? '';

switch ($action) {

    case 'list': {
        $q = trim($_GET['q'] ?? '');
        $village = trim($_GET['village'] ?? ''); // village english filter
        $sql = "SELECT * FROM moi_records WHERE 1=1";
        $params = []; $types = '';
        if ($q !== '') {
            $sql .= " AND (id LIKE ? OR name_tamil LIKE ? OR name_english LIKE ? OR village_tamil LIKE ?
                       OR village_english LIKE ? OR mobile LIKE ? OR alternate_mobile LIKE ? OR city LIKE ? OR income LIKE ?
                       OR expenditure LIKE ? OR information LIKE ?)";
            $like = "%$q%";
            for ($i=0;$i<11;$i++) { $params[] = $like; $types .= 's'; }
        }
        if ($village !== '') { $sql .= " AND village_english = ?"; $params[] = $village; $types .= 's'; }
        $sql .= " ORDER BY id DESC";
        $stmt = $db->prepare($sql);
        if ($params) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        json_out(['rows' => $stmt->get_result()->fetch_all(MYSQLI_ASSOC)]);
    }

    case 'villages': {
        $res = $db->query("SELECT DISTINCT village_english FROM moi_records WHERE village_english IS NOT NULL AND village_english<>'' ORDER BY village_english ASC");
        json_out(['villages' => array_map(fn($r) => $r['village_english'], $res->fetch_all(MYSQLI_ASSOC))]);
    }

    case 'add': {
        $f = fn($k) => trim($_POST[$k] ?? '');
        $nt = $f('name_tamil'); $ne = $f('name_english'); $vt = $f('village_tamil');
        $ve = $f('village_english'); $mobile = $f('mobile'); $altMobile = $f('alternate_mobile');
        $city = $f('city'); $info = $f('information');
        $income = floatval($_POST['income'] ?? 0);
        $expenditure = floatval($_POST['expenditure'] ?? 0);
        $stmt = $db->prepare("INSERT INTO moi_records
            (name_tamil,name_english,village_tamil,village_english,mobile,alternate_mobile,city,income,expenditure,information)
            VALUES (?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('sssssssdds',
            $nt, $ne, $vt, $ve, $mobile, $altMobile, $city, $income, $expenditure, $info);
        $ok = $stmt->execute();
        json_out(['success' => $ok, 'id' => $db->insert_id, 'message' => $ok ? 'Saved successfully.' : $db->error]);
    }

    case 'update': {
        $id = intval($_POST['id'] ?? 0);
        if ($id <= 0) json_out(['success'=>false,'message'=>'Invalid ID']);
        $f = fn($k) => trim($_POST[$k] ?? '');
        $income = floatval($_POST['income'] ?? 0);
        $expenditure = floatval($_POST['expenditure'] ?? 0);
        $stmt = $db->prepare("UPDATE moi_records SET
            name_tamil=?, name_english=?, village_tamil=?, village_english=?, mobile=?, alternate_mobile=?, city=?,
            income=?, expenditure=?, information=? WHERE id=?");
        $nt = $f('name_tamil'); $ne = $f('name_english'); $vt = $f('village_tamil');
        $ve = $f('village_english'); $mobile = $f('mobile'); $altMobile = $f('alternate_mobile');
        $city = $f('city'); $info = $f('information');
        $stmt->bind_param('sssssssddsi', $nt, $ne, $vt, $ve, $mobile, $altMobile, $city, $income, $expenditure, $info, $id);
        $ok = $stmt->execute();
        json_out(['success' => $ok, 'message' => $ok ? 'Updated successfully.' : $db->error]);
    }

    default:
        json_out(['error' => 'Unknown action']);
}
