<?php
require_once 'config.php';
$db = getDB();
$action = $_REQUEST['action'] ?? '';

switch ($action) {

    // ---------------- LIST / SEARCH ----------------
    case 'list': {
        $q = trim($_GET['q'] ?? '');
        $village = trim($_GET['village'] ?? '');
        $sql = "SELECT * FROM interest_customers WHERE 1=1";
        $params = []; $types = '';

        if ($q !== '') {
            $sql .= " AND (id LIKE ? OR name LIKE ? OR village LIKE ? OR mobile LIKE ?
                       OR principal LIKE ? OR principal_balance LIKE ? OR rate_of_interest LIKE ?
                       OR transaction_date LIKE ? OR no_of_payments LIKE ? OR total_interest_collected LIKE ?)";
            $like = "%$q%";
            for ($i=0;$i<10;$i++) { $params[] = $like; $types .= 's'; }
        }
        if ($village !== '') {
            $sql .= " AND village = ?";
            $params[] = $village; $types .= 's';
        }
        $sql .= " ORDER BY id DESC";
        $stmt = $db->prepare($sql);
        if ($params) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        json_out(['rows' => $rows]);
    }

    // ---------------- VILLAGE LIST (for filter dropdown) ----------------
    case 'villages': {
        $res = $db->query("SELECT DISTINCT village FROM interest_customers ORDER BY village ASC");
        $list = array_map(fn($r) => $r['village'], $res->fetch_all(MYSQLI_ASSOC));
        json_out(['villages' => $list]);
    }

    // ---------------- ADD NEW CUSTOMER ----------------
    case 'add': {
        $name = trim($_POST['name'] ?? '');
        $village = trim($_POST['village'] ?? '');
        $mobile = trim($_POST['mobile'] ?? '');
        $principal = floatval($_POST['principal'] ?? 0);
        $rate = floatval($_POST['rate_of_interest'] ?? 0);
        $date = $_POST['transaction_date'] ?? date('Y-m-d');
        $payment_type = '100days'; // schedule field removed from UI; stored with a default value

        if ($name === '' || $mobile === '' || $principal <= 0) {
            json_out(['success' => false, 'message' => 'Name, mobile and principal are required.']);
        }
        $stmt = $db->prepare("INSERT INTO interest_customers
            (name,village,mobile,principal,principal_balance,rate_of_interest,transaction_date,payment_type)
            VALUES (?,?,?,?,?,?,?,?)");
        $stmt->bind_param('sssddsss', $name,$village,$mobile,$principal,$principal,$rate,$date,$payment_type);
        $ok = $stmt->execute();
        json_out(['success' => $ok, 'id' => $db->insert_id, 'message' => $ok ? 'Saved successfully.' : $db->error]);
    }

    // ---------------- VIEW CUSTOMER (3-part detail) ----------------
    case 'view': {
        $id = intval($_GET['id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM interest_customers WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $customer = $stmt->get_result()->fetch_assoc();
        if (!$customer) json_out(['success'=>false,'message'=>'Not found']);

        $stmt2 = $db->prepare("SELECT * FROM interest_collections WHERE customer_id=? ORDER BY collection_date DESC");
        $stmt2->bind_param('i', $id);
        $stmt2->execute();
        $interestHistory = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);

        $stmt3 = $db->prepare("SELECT * FROM interest_principal_collections WHERE customer_id=? ORDER BY collection_date DESC");
        $stmt3->bind_param('i', $id);
        $stmt3->execute();
        $principalHistory = $stmt3->get_result()->fetch_all(MYSQLI_ASSOC);

        json_out(['success'=>true,'customer'=>$customer,'interest_history'=>$interestHistory,'principal_history'=>$principalHistory]);
    }

    // ---------------- COLLECT INTEREST (row Pay button OR view tab) ----------------
    // Payment status is derived automatically from the loan's principal balance:
    // 'complete' only once principal_balance is 0, otherwise 'partial'.
    case 'collect_interest': {
        $id = intval($_POST['id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $date = $_POST['date'] ?? date('Y-m-d');

        if ($id <= 0 || $amount <= 0) json_out(['success'=>false,'message'=>'Invalid data']);

        $stmt0 = $db->prepare("SELECT principal_balance FROM interest_customers WHERE id=?");
        $stmt0->bind_param('i', $id);
        $stmt0->execute();
        $row = $stmt0->get_result()->fetch_assoc();
        if (!$row) json_out(['success'=>false,'message'=>'Customer not found']);
        $status = (floatval($row['principal_balance']) <= 0) ? 'complete' : 'partial';

        $stmt = $db->prepare("INSERT INTO interest_collections (customer_id, collection_date, amount, status) VALUES (?,?,?,?)");
        $stmt->bind_param('isds', $id, $date, $amount, $status);
        $ok = $stmt->execute();

        if ($ok) {
            $db->query("UPDATE interest_customers SET
                total_interest_collected = total_interest_collected + $amount,
                no_of_payments = no_of_payments + 1
                WHERE id = $id");
        }
        json_out(['success'=>$ok, 'status'=>$status, 'message'=>$ok?'Interest collected.':$db->error]);
    }

    // ---------------- COLLECT PRINCIPAL ----------------
    case 'collect_principal': {
        $id = intval($_POST['id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $date = $_POST['date'] ?? date('Y-m-d');

        if ($id <= 0 || $amount <= 0) json_out(['success'=>false,'message'=>'Invalid data']);

        $stmt = $db->prepare("SELECT principal_balance FROM interest_customers WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $bal = $stmt->get_result()->fetch_assoc()['principal_balance'] ?? 0;
        if ($amount > $bal) json_out(['success'=>false,'message'=>'Amount exceeds remaining principal balance.']);

        $stmt2 = $db->prepare("INSERT INTO interest_principal_collections (customer_id, collection_date, amount, status) VALUES (?,?,?,?)");
        $newBalance = $bal - $amount;
        $status = ($newBalance <= 0) ? 'complete' : 'partial';
        $stmt2->bind_param('isds', $id, $date, $amount, $status);
        $ok = $stmt2->execute();

        if ($ok) {
            $db->query("UPDATE interest_customers SET principal_balance = principal_balance - $amount WHERE id = $id");
        }
        json_out(['success'=>$ok, 'status'=>$status, 'message'=>$ok?'Principal collected.':$db->error]);
    }

    default:
        json_out(['error' => 'Unknown action']);
}
